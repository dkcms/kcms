$(document).ready(function(){
	$("[data-toggle='tooltip']").tooltip();
	//$('.news-detail .news-content img').addClass("img-responsive");
});
