<?php
return array (
  'ckm3u8' => 
  array (
    0 => 'Ckm3u8',
    1 => 'M3u8播放器',
    2 => '0',
    3 => '',
  ),
);
?>