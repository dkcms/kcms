cms_player.yun = false;
document.write('<iframe class="embed-responsive-item" src="//cdn.feifeicms.co/player/1.0/copyright.html?'+cms_player.copyright+'" width="100%" height="100%" frameborder="0" scrolling="no" allowfullscreen="true"></iframe>');
window.setTimeout("window.location='"+cms_player.url+"'",(cms_player.copyright*1000));