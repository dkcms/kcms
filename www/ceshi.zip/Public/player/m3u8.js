cms_player.yun = false;
document.write('<script type="text/javascript" src="//cdn.feifeicms.co/player/4.1/?type=m3u8&u='+cms_player.url+'"></script>');