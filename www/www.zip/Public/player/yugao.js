cms_player.yun = false;
document.write('<script type="text/javascript" src="//cdn.feifeicms.co/player/4.1/?type=yugao&u='+cms_player.url+'"></script>');