<?php
return array(
	'TMPL_TEMPLATE_SUFFIX' => '.tpl'
);
?>