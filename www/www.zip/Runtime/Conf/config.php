<?php
return array (
  'db_type' => 'mysql',
  'db_host' => 'localhost',
  'db_name' => 'root',
  'db_user' => 'root',
  'db_pwd' => 'root',
  'db_port' => '3306',
  'db_prefix' => 'ff_',
  'default_theme' => 'defalut',
  'default_theme_m' => 'defalut',
  'site_name' => '资源发布站',
  'site_path' => '/',
  'site_domain' => 'a.com',
  'site_domain_m' => '',
  'site_title' => '资源发布站首页',
  'site_keywords' => '资源发布系统,电影网站API程序',
  'site_description' => '努力打造为最好的影视资源发布系统!',
  'site_email' => '110119@qq.com',
  'site_copyright' => '本网站为非赢利性站点，本网站所有内容均来源于互联网相关站点自动搜索采集信息，相关链接已经注明来源。',
  'site_hot' => '资源发布站',
  'site_tongji' => '',
  'site_icp' => 'ICP备2010111号',
  'admin_ads_file' => 'Runtime/Js',
  'admin_order_type' => 'addtime',
  'tmpl_cache_on' => false,
  'data_cache_type' => 'file',
  'cache_foreach' => '0',
  'cache_page_list' => '0',
  'cache_page_type' => '0',
  'cache_page_vod' => '0',
  'cache_page_news' => '0',
  'cache_page_special' => '0',
  'cache_page_user' => '0',
  'cache_page_cm' => '0',
  'cache_page_forum' => '0',
  'cache_page_images' => '0',
  'cache_foreach_prefix' => '5e1b266575588',
  'upload_path' => 'Uploads',
  'upload_style' => 'Y-m-d',
  'upload_class' => 'jpg,gif,png,jpeg',
  'upload_thumb' => 0,
  'upload_thumb_w' => '120',
  'upload_thumb_h' => '140',
  'upload_water' => false,
  'upload_water_img' => './Public/images/water.gif',
  'upload_water_pct' => '75',
  'upload_water_pos' => '9',
  'upload_face_width' => '0',
  'upload_face_height' => '0',
  'upload_http' => false,
  'upload_http_down' => '5',
  'upload_http_prefix' => '',
  'upload_ftp' => false,
  'upload_ftp_host' => '',
  'upload_ftp_user' => '',
  'upload_ftp_pass' => '',
  'upload_ftp_port' => '',
  'upload_ftp_dir' => '',
  'upload_ftp_del' => '0',
  'upload_safety' => '',
  'play_width' => '640',
  'play_height' => '420',
  'play_playad' => 'http://cdn.feifeicms.co/loading/3.0/',
  'play_second' => 10,
  'play_language' => '国语,英语,粤语,闽南语,韩语,日语,国语/粤语,其它',
  'play_area' => '大陆,香港,台湾,美国,韩国,日本,泰国,新加坡,马来西亚,印度,英国,法国,加拿大,西班牙,俄罗斯,其它',
  'play_year' => '2019,2018,2017,2016,2015,2014,2013,2012,2011,2010,2009',
  'play_server' => 
  array (
    '' => '',
  ),
  'play_type' => '爱情,动作,喜剧,战争,科幻,剧情,武侠,冒险,枪战,恐怖,微电影,其它',
  'play_state' => '正片,预告片,花絮',
  'play_version' => '高清版,剧场版,抢先版,OVA,TV,影院版',
  'play_jiexi' => '',
  'play_weekday' => '一,二,三,四,五,六,日',
  'collect_original' => false,
  'collect_time' => '1',
  'collect_name' => '0',
  'collect_ips' => '',
  'collect_hits' => '99',
  'collect_updown' => '99',
  'collect_gold' => '9',
  'collect_golder' => '99',
  'collect_tags' => '0',
  'collect_passwd' => '',
  'collect_forum' => '3000',
  'news_type' => '多分类1,多分类2,多分类3,多分类4',
  'user_second' => '3600',
  'user_replace' => '她妈|它妈|他妈|你妈|去死|贱人',
  'user_check' => '0',
  'url_rewrite' => '0',
  'url_router_on' => '0',
  'url_html_suffix' => '.html',
  'url_html' => '0',
  'url_vod_list' => 'video/{listdir}/{id}-{page}',
  'url_vod_detail' => 'Runtime/{listdir}/{id}/',
  'url_vod_play' => 'Runtime/{listdir}/{id}/{sid}-{pid}',
  'url_news_list' => 'news/{listdir}/{id}-{page}',
  'url_news_detail' => 'Runtime/{listdir}/{id}/{page}',
  'url_time' => '1',
  'url_number' => '10',
  'html_home_suffix' => '.html',
  'html_cache_on' => false,
  'html_cache_time' => 0,
  'html_read_type' => 0,
  'html_file_suffix' => '.html',
  'html_cache_index' => '1',
  'html_cache_list' => '1.5',
  'html_cache_content' => '12',
  'html_cache_play' => '12',
  'html_cache_iframe' => '12',
  'html_cache_type' => '0.5',
  'html_cache_ajax' => '12',
  '_htmls_' => 
  array (
    'home:index:index' => NULL,
    'home:vod:type' => NULL,
    'home:news:type' => NULL,
    'home:vod:show' => NULL,
    'home:news:show' => NULL,
    'home:vod:read' => NULL,
    'home:news:read' => NULL,
    'home:vod:play' => NULL,
    'home:my:show' => NULL,
  ),
  'rewrite_route' => 'list-ename===neidi===id=neidi
list-ename===hanju===id=hanju
list-ename===gangju===id=gangju
list-ename===meiju===id=meiju
list-ename===taiwan===id=taiwan
list-ename===riju===id=riju
list-ename===taiju===id=taiju
list-ename===haiwai===id=haiwai
list-ename===dongzuo===id=dongzuo
list-ename===xiju===id=xiju
list-ename===aiqing===id=aiqing
list-ename===kehuan===id=kehuan
list-ename===kongbu===id=kongbu
list-ename===juqing===id=juqing
list-ename===zhanzheng===id=zhanzheng
list-ename===jilu===id=jilu
list-ename===donghua===id=donghua
list-ename===lunli===id=lunli
list-ename===wei===id=wei
list-ename===dongman===id=dongman
list-ename===zongyi===id=zongyi
list-ename===special===id=zhuanti
special-read-id-(:letternum)===special/(:letternum)
vod-search-actor-(:any)===actor/(:any)
vod-search-director-(:any)===director/(:any)
vod-search-writer-(:any)===writer/(:any)
vod-search-wd-(:any)===search/(:any)
map-vod-id-(:letternum)-limit-(:num)-p-(:num)===sitemap/(:letternum)/(:num)/(:num)
map-vod-id-(:letternum)-limit-(:num)===sitemap/(:letternum)/(:num)
list-ename-id-(:letternum)-p-(:num)===(:letternum)/p(:num)
vod-ename-dir-(:letternum)-id-(:letternum)===(:letternum)/(:letternum)
vod-eplay-dir-(:letternum)-id-(:letternum)-sid-(:num)-pid-(:num)===(:letternum)/(:letternum)/(:num)-(:num)
list-select-id-(:num)-type-(:any)-area-(:any)-year-(:any)-star-(:any)-state-(:any)-order-(:letternum)-p-(:num)===select/(:num)-(:any)-(:any)-(:any)-(:any)-(:any)-(:letternum)-(:num)
list-select-id-(:num)-type-(:any)-area-(:any)-year-(:any)-star-(:any)-state-(:any)-order-(:letternum)===select/(:num)-(:any)-(:any)-(:any)-(:any)-(:any)-(:letternum)',
  'url_rewrite_rules' => 
  array (
    'list/enameid=neidi' => 
    array (
      'find' => 'list-ename',
      'replace' => 'neidi',
    ),
    'list/enameid=hanju' => 
    array (
      'find' => 'list-ename',
      'replace' => 'hanju',
    ),
    'list/enameid=gangju' => 
    array (
      'find' => 'list-ename',
      'replace' => 'gangju',
    ),
    'list/enameid=meiju' => 
    array (
      'find' => 'list-ename',
      'replace' => 'meiju',
    ),
    'list/enameid=taiwan' => 
    array (
      'find' => 'list-ename',
      'replace' => 'taiwan',
    ),
    'list/enameid=riju' => 
    array (
      'find' => 'list-ename',
      'replace' => 'riju',
    ),
    'list/enameid=taiju' => 
    array (
      'find' => 'list-ename',
      'replace' => 'taiju',
    ),
    'list/enameid=haiwai' => 
    array (
      'find' => 'list-ename',
      'replace' => 'haiwai',
    ),
    'list/enameid=dongzuo' => 
    array (
      'find' => 'list-ename',
      'replace' => 'dongzuo',
    ),
    'list/enameid=xiju' => 
    array (
      'find' => 'list-ename',
      'replace' => 'xiju',
    ),
    'list/enameid=aiqing' => 
    array (
      'find' => 'list-ename',
      'replace' => 'aiqing',
    ),
    'list/enameid=kehuan' => 
    array (
      'find' => 'list-ename',
      'replace' => 'kehuan',
    ),
    'list/enameid=kongbu' => 
    array (
      'find' => 'list-ename',
      'replace' => 'kongbu',
    ),
    'list/enameid=juqing' => 
    array (
      'find' => 'list-ename',
      'replace' => 'juqing',
    ),
    'list/enameid=zhanzheng' => 
    array (
      'find' => 'list-ename',
      'replace' => 'zhanzheng',
    ),
    'list/enameid=jilu' => 
    array (
      'find' => 'list-ename',
      'replace' => 'jilu',
    ),
    'list/enameid=donghua' => 
    array (
      'find' => 'list-ename',
      'replace' => 'donghua',
    ),
    'list/enameid=lunli' => 
    array (
      'find' => 'list-ename',
      'replace' => 'lunli',
    ),
    'list/enameid=wei' => 
    array (
      'find' => 'list-ename',
      'replace' => 'wei',
    ),
    'list/enameid=dongman' => 
    array (
      'find' => 'list-ename',
      'replace' => 'dongman',
    ),
    'list/enameid=zongyi' => 
    array (
      'find' => 'list-ename',
      'replace' => 'zongyi',
    ),
    'list/enameid=zhuanti' => 
    array (
      'find' => 'list-ename',
      'replace' => 'special',
    ),
    'special/read/id' => 
    array (
      'find' => 'special-read-id-([A-Za-z0-9]+)',
      'replace' => 'special/$1',
    ),
    'vod/search/actor' => 
    array (
      'find' => 'vod-search-actor-(.*)',
      'replace' => 'actor/$1',
    ),
    'vod/search/director' => 
    array (
      'find' => 'vod-search-director-(.*)',
      'replace' => 'director/$1',
    ),
    'vod/search/writer' => 
    array (
      'find' => 'vod-search-writer-(.*)',
      'replace' => 'writer/$1',
    ),
    'vod/search/wd' => 
    array (
      'find' => 'vod-search-wd-(.*)',
      'replace' => 'search/$1',
    ),
    'map/vod/id/limit/p' => 
    array (
      'find' => 'map-vod-id-([A-Za-z0-9]+)-limit-([0-9]+)-p-([0-9]+)',
      'replace' => 'sitemap/$1/$2/$3',
    ),
    'map/vod/id/limit' => 
    array (
      'find' => 'map-vod-id-([A-Za-z0-9]+)-limit-([0-9]+)',
      'replace' => 'sitemap/$1/$2',
    ),
    'list/ename/id/p' => 
    array (
      'find' => 'list-ename-id-([A-Za-z0-9]+)-p-([0-9]+)',
      'replace' => '$1/p$2',
    ),
    'vod/ename/dir/id' => 
    array (
      'find' => 'vod-ename-dir-([A-Za-z0-9]+)-id-([A-Za-z0-9]+)',
      'replace' => '$1/$2',
    ),
    'vod/eplay/dir/id/sid/pid' => 
    array (
      'find' => 'vod-eplay-dir-([A-Za-z0-9]+)-id-([A-Za-z0-9]+)-sid-([0-9]+)-pid-([0-9]+)',
      'replace' => '$1/$2/$3-$4',
    ),
    'list/select/id/type/area/year/star/state/order/p' => 
    array (
      'find' => 'list-select-id-([0-9]+)-type-(.*)-area-(.*)-year-(.*)-star-(.*)-state-(.*)-order-([A-Za-z0-9]+)-p-([0-9]+)',
      'replace' => 'select/$1-$2-$3-$4-$5-$6-$7-$8',
    ),
    'list/select/id/type/area/year/star/state/order' => 
    array (
      'find' => 'list-select-id-([0-9]+)-type-(.*)-area-(.*)-year-(.*)-star-(.*)-state-(.*)-order-([A-Za-z0-9]+)',
      'replace' => 'select/$1-$2-$3-$4-$5-$6-$7',
    ),
  ),
  'url_route_rules' => 
  array (
    0 => 
    array (
      0 => '/neidi$/',
      1 => 'list/ename',
      2 => NULL,
      3 => 'id=neidi',
    ),
    1 => 
    array (
      0 => '/hanju$/',
      1 => 'list/ename',
      2 => NULL,
      3 => 'id=hanju',
    ),
    2 => 
    array (
      0 => '/gangju$/',
      1 => 'list/ename',
      2 => NULL,
      3 => 'id=gangju',
    ),
    3 => 
    array (
      0 => '/meiju$/',
      1 => 'list/ename',
      2 => NULL,
      3 => 'id=meiju',
    ),
    4 => 
    array (
      0 => '/taiwan$/',
      1 => 'list/ename',
      2 => NULL,
      3 => 'id=taiwan',
    ),
    5 => 
    array (
      0 => '/riju$/',
      1 => 'list/ename',
      2 => NULL,
      3 => 'id=riju',
    ),
    6 => 
    array (
      0 => '/taiju$/',
      1 => 'list/ename',
      2 => NULL,
      3 => 'id=taiju',
    ),
    7 => 
    array (
      0 => '/haiwai$/',
      1 => 'list/ename',
      2 => NULL,
      3 => 'id=haiwai',
    ),
    8 => 
    array (
      0 => '/dongzuo$/',
      1 => 'list/ename',
      2 => NULL,
      3 => 'id=dongzuo',
    ),
    9 => 
    array (
      0 => '/xiju$/',
      1 => 'list/ename',
      2 => NULL,
      3 => 'id=xiju',
    ),
    10 => 
    array (
      0 => '/aiqing$/',
      1 => 'list/ename',
      2 => NULL,
      3 => 'id=aiqing',
    ),
    11 => 
    array (
      0 => '/kehuan$/',
      1 => 'list/ename',
      2 => NULL,
      3 => 'id=kehuan',
    ),
    12 => 
    array (
      0 => '/kongbu$/',
      1 => 'list/ename',
      2 => NULL,
      3 => 'id=kongbu',
    ),
    13 => 
    array (
      0 => '/juqing$/',
      1 => 'list/ename',
      2 => NULL,
      3 => 'id=juqing',
    ),
    14 => 
    array (
      0 => '/zhanzheng$/',
      1 => 'list/ename',
      2 => NULL,
      3 => 'id=zhanzheng',
    ),
    15 => 
    array (
      0 => '/jilu$/',
      1 => 'list/ename',
      2 => NULL,
      3 => 'id=jilu',
    ),
    16 => 
    array (
      0 => '/donghua$/',
      1 => 'list/ename',
      2 => NULL,
      3 => 'id=donghua',
    ),
    17 => 
    array (
      0 => '/lunli$/',
      1 => 'list/ename',
      2 => NULL,
      3 => 'id=lunli',
    ),
    18 => 
    array (
      0 => '/wei$/',
      1 => 'list/ename',
      2 => NULL,
      3 => 'id=wei',
    ),
    19 => 
    array (
      0 => '/dongman$/',
      1 => 'list/ename',
      2 => NULL,
      3 => 'id=dongman',
    ),
    20 => 
    array (
      0 => '/zongyi$/',
      1 => 'list/ename',
      2 => NULL,
      3 => 'id=zongyi',
    ),
    21 => 
    array (
      0 => '/special$/',
      1 => 'list/ename',
      2 => NULL,
      3 => 'id=zhuanti',
    ),
    22 => 
    array (
      0 => '/special\\/([A-Za-z0-9]+)$/',
      1 => 'special/read',
      2 => 'id',
      3 => NULL,
    ),
    23 => 
    array (
      0 => '/actor\\/(.*)$/',
      1 => 'vod/search',
      2 => 'actor',
      3 => NULL,
    ),
    24 => 
    array (
      0 => '/director\\/(.*)$/',
      1 => 'vod/search',
      2 => 'director',
      3 => NULL,
    ),
    25 => 
    array (
      0 => '/writer\\/(.*)$/',
      1 => 'vod/search',
      2 => 'writer',
      3 => NULL,
    ),
    26 => 
    array (
      0 => '/search\\/(.*)$/',
      1 => 'vod/search',
      2 => 'wd',
      3 => NULL,
    ),
    27 => 
    array (
      0 => '/sitemap\\/([A-Za-z0-9]+)\\/([0-9]+)\\/([0-9]+)$/',
      1 => 'map/vod',
      2 => 'id,limit,p',
      3 => NULL,
    ),
    28 => 
    array (
      0 => '/sitemap\\/([A-Za-z0-9]+)\\/([0-9]+)$/',
      1 => 'map/vod',
      2 => 'id,limit',
      3 => NULL,
    ),
    29 => 
    array (
      0 => '/([A-Za-z0-9]+)\\/p([0-9]+)$/',
      1 => 'list/ename',
      2 => 'id,p',
      3 => NULL,
    ),
    30 => 
    array (
      0 => '/([A-Za-z0-9]+)\\/([A-Za-z0-9]+)$/',
      1 => 'vod/ename',
      2 => 'dir,id',
      3 => NULL,
    ),
    31 => 
    array (
      0 => '/([A-Za-z0-9]+)\\/([A-Za-z0-9]+)\\/([0-9]+)-([0-9]+)$/',
      1 => 'vod/eplay',
      2 => 'dir,id,sid,pid',
      3 => NULL,
    ),
    32 => 
    array (
      0 => '/select\\/([0-9]+)-(.*)-(.*)-(.*)-(.*)-(.*)-([A-Za-z0-9]+)-([0-9]+)$/',
      1 => 'list/select',
      2 => 'id,type,area,year,star,state,order,p',
      3 => NULL,
    ),
    33 => 
    array (
      0 => '/select\\/([0-9]+)-(.*)-(.*)-(.*)-(.*)-(.*)-([A-Za-z0-9]+)$/',
      1 => 'list/select',
      2 => 'id,type,area,year,star,state,order',
      3 => NULL,
    ),
  ),
  'seo_cm_title' => '精彩影评',
  'seo_cm_keywords' => '影评,剧评,观后感,评论',
  'seo_cm_description' => '提供很多精彩的影视评论，欢迎阅读。',
  'forum_type' => 'feifei',
  'forum_type_uyan_uid' => '1528513',
  'forum_type_changyan_appid' => 'cysXPib5E',
  'forum_type_changyan_conf' => 'prod_68505537e56f813cfafdcf88027d242e',
  'forum_seo_title' => '',
  'forum_seo_keywords' => '',
  'forum_seo_description' => '',
  'app_sub_domain_deploy' => 0,
  'app_sub_domain_rules' => '',
  'user_register' => '0',
  'user_register_check' => '0',
  'user_register_score' => '10',
  'user_register_second' => '3600',
  'user_forum' => '0',
  'user_pay_scale' => '10',
  'user_pay_small' => '5',
  'user_pay_vip_ext' => '10',
  'user_pay_vip_small' => '5',
  'user_pay_appid' => '',
  'user_pay_appkey' => '',
  'user_register_score_pid' => '0',
  'user_register_vipday' => '0',
  'user_register_welcome' => '',
  'ui_scenario' => '10',
  'ui_record' => '10',
  'ui_playurl' => '34',
  'ui_slide_index' => '3000',
  'ui_search_limit' => 10,
  'ui_slide_max' => '8',
  'email_host' => '',
  'email_username' => '',
  'email_password' => '',
  'email_usertest' => '',
  'email_port' => '',
  'email_secure' => '',
  'pay_alipay_account' => '',
  'pay_alipay_appid' => '',
  'pay_alipay_appkey' => '',
  'pay_wxpay_account' => '',
  'pay_wxpay_appid' => '',
  'pay_wxpay_appkey' => '',
  'pay_paypal_account' => '',
  'wx_check' => '0',
  'wx_cids' => '',
  'wx_limit' => '',
  'wx_order' => '',
  'wx_token' => '',
  'wx_follow' => '',
  'wx_none_txt' => '',
  'wx_none_url' => '',
  'wx_domain' => '',
  'wx_jiexi' => '',
  'wx_item' => 
  array (
    'keyword' => 
    array (
    ),
    'title' => 
    array (
    ),
    'content' => 
    array (
    ),
    'pic' => 
    array (
    ),
    'link' => 
    array (
    ),
  ),
  'apikey_keyword' => '',
  'apikey_douban' => '',
  'pay_card_sell' => '',
  'pay_rj_appid' => '',
  'pay_rj_appkey' => '',
  'pay_code_appid' => '',
  'pay_code_appkey' => '',
  'pay_code_type' => '',
  'pay_code_act' => '0',
  'url_list' => 'Runtime/{listdir}/{page}',
  'special_type' => '多分类1,多分类2,多分类3,多分类4',
  'star_type' => '多分类1,多分类2,多分类3,多分类4',
  'role_type' => '多分类1,多分类2,多分类3,多分类4',
  'play_buffer' => '',
  'play_pause' => '',
  'play_live' => '',
  'cache_page_person' => '0',
  'collect_actor' => '0',
  'user_email_forum' => '0',
  'user_email_guestbook' => '0',
  'user_email_error' => '0',
  'upload_referer' => '',
);
?>