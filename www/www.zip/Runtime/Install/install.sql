﻿SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

CREATE TABLE IF NOT EXISTS `ff_admin` (
  `admin_id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(50) NOT NULL,
  `admin_pwd` char(32) NOT NULL,
  `admin_count` smallint(6) NOT NULL,
  `admin_ok` varchar(50) NOT NULL,
  `admin_del` bigint(1) NOT NULL,
  `admin_ip` varchar(40) NOT NULL,
  `admin_email` varchar(40) NOT NULL,
  `admin_logintime` int(11) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;
INSERT INTO `ff_admin` (`admin_id`, `admin_name`, `admin_pwd`, `admin_count`, `admin_ok`, `admin_del`, `admin_ip`, `admin_email`, `admin_logintime`) VALUES
(1, 'admin', 'e70345b9cc61dd439be639c64c3b7712', 206, '1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1', 0, '127.0.0.1', 'admin@qq.com', 1503632165);

CREATE TABLE IF NOT EXISTS `ff_ads` (
  `ads_id` smallint(4) unsigned NOT NULL AUTO_INCREMENT,
  `ads_name` varchar(50) NOT NULL,
  `ads_content` text NOT NULL,
  PRIMARY KEY (`ads_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;
INSERT INTO `ff_ads` (`ads_id`, `ads_name`, `ads_content`) VALUES
(1, '90_m', '工具>网站广告管理>广告标识（90_m）'),
(2, '60_m', '工具>网站广告管理>广告标识（60_m）'),
(3, '300_250', '工具>网站广告管理>广告标识（300_250）'),
(4, '300_250m', '工具>网站广告管理>广告标识（300_250m）'),
(5, '300_300', '工具>网站广告管理>广告标识（300_300）'),
(6, '960_90', '工具>网站广告管理>广告标识（960_90）'),
(7, '300_15', '运营>广告管理>广告标识（300_15）'),
(8, '300_15m', '运营>广告管理>广告标识（300_15m）');

CREATE TABLE IF NOT EXISTS `ff_card` (
  `card_id` int(11) NOT NULL AUTO_INCREMENT,
  `card_number` varchar(64) NOT NULL,
  `card_face` mediumint(8) NOT NULL,
  `card_uid` int(11) NOT NULL DEFAULT '0',
  `card_status` tinyint(1) NOT NULL DEFAULT '0',
  `card_addtime` int(11) NOT NULL,
  `card_usetime` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`card_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `ff_cj` (
  `cj_id` smallint(6) NOT NULL AUTO_INCREMENT,
  `cj_name` varchar(255) NOT NULL,
  `cj_url` varchar(255) NOT NULL,
  `cj_type` tinyint(2) NOT NULL DEFAULT '1',
  `cj_appid` varchar(50) NOT NULL,
  `cj_appkey` varchar(50) NOT NULL,
  PRIMARY KEY (`cj_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `ff_forum` (
  `forum_id` mediumint(9) unsigned NOT NULL AUTO_INCREMENT,
  `forum_cid` mediumint(9) NOT NULL,
  `forum_cid_ep` smallint(5) NOT NULL,
  `forum_sid` tinyint(1) NOT NULL DEFAULT '1',
  `forum_uid` mediumint(9) NOT NULL DEFAULT '1',
  `forum_pid` mediumint(9) NOT NULL DEFAULT '0',
  `forum_title` varchar(255) NOT NULL,
  `forum_content` text NOT NULL,
  `forum_up` mediumint(9) NOT NULL DEFAULT '0',
  `forum_down` mediumint(9) NOT NULL DEFAULT '0',
  `forum_reply` mediumint(9) NOT NULL DEFAULT '0',
  `forum_report` mediumint(9) NOT NULL DEFAULT '0',
  `forum_ip` varchar(20) NOT NULL,
  `forum_addtime` int(11) NOT NULL,
  `forum_status` tinyint(1) NOT NULL DEFAULT '0',
  `forum_istop` tinyint(1) NOT NULL DEFAULT '0',
  `forum_referer` varchar(150) NOT NULL,
  PRIMARY KEY (`forum_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `ff_link` (
  `link_id` tinyint(4) unsigned NOT NULL AUTO_INCREMENT,
  `link_name` varchar(255) NOT NULL,
  `link_logo` varchar(255) NOT NULL,
  `link_url` varchar(255) NOT NULL,
  `link_order` tinyint(4) NOT NULL,
  `link_type` tinyint(1) NOT NULL,
  PRIMARY KEY (`link_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `ff_list` (
  `list_id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `list_pid` smallint(3) NOT NULL,
  `list_oid` smallint(3) NOT NULL,
  `list_sid` tinyint(1) NOT NULL,
  `list_name` char(20) NOT NULL,
  `list_skin` char(20) NOT NULL,
  `list_skin_detail` varchar(20) NOT NULL DEFAULT 'detail',
  `list_skin_play` varchar(20) NOT NULL DEFAULT 'play',
  `list_skin_type` varchar(20) NOT NULL DEFAULT 'type',
  `list_dir` varchar(90) NOT NULL,
  `list_status` tinyint(1) NOT NULL DEFAULT '1',
  `list_keywords` varchar(255) NOT NULL,
  `list_title` varchar(50) NOT NULL,
  `list_description` varchar(255) NOT NULL,
  `list_copyright` smallint(3) NOT NULL,
  `list_ispay` tinyint(1) NOT NULL DEFAULT '0',
  `list_price` smallint(6) NOT NULL DEFAULT '0',
  `list_trysee` smallint(6) NOT NULL DEFAULT '0',
  `list_extend` text,
  PRIMARY KEY (`list_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `ff_nav` (
  `nav_id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `nav_pid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `nav_oid` tinyint(3) NOT NULL DEFAULT '1',
  `nav_title` varchar(50) NOT NULL DEFAULT '',
  `nav_tips` varchar(50) NOT NULL DEFAULT '',
  `nav_link` varchar(255) NOT NULL DEFAULT '',
  `nav_status` tinyint(1) NOT NULL DEFAULT '1',
  `nav_target` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`nav_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC AUTO_INCREMENT=1 ;
INSERT INTO `ff_nav` (`nav_id`, `nav_pid`, `nav_oid`, `nav_title`, `nav_tips`, `nav_link`, `nav_status`, `nav_target`) VALUES
(1, 0, 1, '首页', 'index', '/', 1, 0);

CREATE TABLE IF NOT EXISTS `ff_news` (
  `news_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `news_cid` smallint(6) NOT NULL DEFAULT '0',
  `news_name` varchar(255) DEFAULT NULL,
  `news_ename` varchar(255) NOT NULL,
  `news_keywords` varchar(255) NOT NULL,
  `news_type` varchar(255) DEFAULT NULL,
  `news_color` char(8) NOT NULL,
  `news_pic` varchar(255) NOT NULL,
  `news_pic_bg` varchar(255) DEFAULT NULL,
  `news_pic_slide` varchar(255) DEFAULT NULL,
  `news_inputer` varchar(50) NOT NULL,
  `news_reurl` varchar(255) NOT NULL,
  `news_remark` text NOT NULL,
  `news_content` text NOT NULL,
  `news_hits` mediumint(8) NOT NULL,
  `news_hits_day` mediumint(8) NOT NULL,
  `news_hits_week` mediumint(8) NOT NULL,
  `news_hits_month` mediumint(8) NOT NULL,
  `news_hits_lasttime` int(11) NOT NULL,
  `news_stars` tinyint(1) NOT NULL,
  `news_status` tinyint(1) NOT NULL DEFAULT '1',
  `news_up` mediumint(8) NOT NULL,
  `news_down` mediumint(8) NOT NULL,
  `news_jumpurl` varchar(255) NOT NULL,
  `news_letter` char(2) NOT NULL,
  `news_addtime` int(8) NOT NULL,
  `news_skin` varchar(30) NOT NULL,
  `news_gold` decimal(3,1) NOT NULL,
  `news_golder` smallint(6) NOT NULL,
  `news_series` varchar(255) NOT NULL,
  PRIMARY KEY (`news_id`),
  KEY `news_cid` (`news_cid`),
  KEY `news_up` (`news_up`),
  KEY `news_down` (`news_down`),
  KEY `news_gold` (`news_gold`),
  KEY `news_hits` (`news_hits`,`news_cid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `ff_orders` (
  `order_id` int(10) NOT NULL AUTO_INCREMENT,
  `order_sign` varchar(32) NOT NULL,
  `order_status` tinyint(1) NOT NULL DEFAULT '0',
  `order_uid` mediumint(8) NOT NULL DEFAULT '0',
  `order_gid` mediumint(8) NOT NULL DEFAULT '0',
  `order_total` smallint(6) NOT NULL,
  `order_money` decimal(18,2) NOT NULL DEFAULT '0.00',
  `order_ispay` tinyint(1) NOT NULL DEFAULT '0',
  `order_shipping` tinyint(1) NOT NULL DEFAULT '0',
  `order_addtime` int(11) NOT NULL,
  `order_paytime` int(11) NOT NULL,
  `order_confirmtime` int(11) NOT NULL,
  `order_info` tinytext NOT NULL,
  `order_paytype` varchar(64) NOT NULL,
  PRIMARY KEY (`order_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `ff_person` (
  `person_id` int(11) NOT NULL AUTO_INCREMENT,
  `person_cid` smallint(6) NOT NULL DEFAULT '0',
  `person_sid` tinyint(3) NOT NULL DEFAULT '8',
  `person_name` varchar(255) NOT NULL,
  `person_alias` varchar(255) NOT NULL,
  `person_ename` varchar(255) NOT NULL,
  `person_blood` varchar(5) NOT NULL,
  `person_gender` varchar(20) NOT NULL,
  `person_weight` smallint(6) NOT NULL,
  `person_height` smallint(6) NOT NULL,
  `person_nationality` varchar(50) NOT NULL,
  `person_birthday` varchar(50) NOT NULL,
  `person_astrology` varchar(50) NOT NULL,
  `person_profession` varchar(255) NOT NULL,
  `person_school` varchar(120) NOT NULL,
  `person_broker` varchar(120) NOT NULL,
  `person_pic` varchar(255) NOT NULL,
  `person_pic_bg` varchar(255) NOT NULL,
  `person_pic_slide` varchar(255) NOT NULL,
  `person_intro` varchar(255) NOT NULL,
  `person_achievement` text NOT NULL,
  `person_content` text NOT NULL,
  `person_addtime` int(11) NOT NULL,
  `person_status` tinyint(1) NOT NULL DEFAULT '1',
  `person_stars` tinyint(1) NOT NULL DEFAULT '0',
  `person_letter` char(2) NOT NULL,
  `person_up` int(11) NOT NULL,
  `person_down` int(11) NOT NULL,
  `person_gold` decimal(3,1) NOT NULL DEFAULT '0.0',
  `person_golder` int(11) NOT NULL,
  `person_hits` int(11) NOT NULL,
  `person_hits_day` int(11) NOT NULL,
  `person_hits_week` int(11) NOT NULL,
  `person_hits_month` int(11) NOT NULL,
  `person_hits_lasttime` int(11) NOT NULL,
  `person_type` varchar(255) NOT NULL,
  `person_title` varchar(255) NOT NULL,
  `person_keywords` varchar(255) NOT NULL,
  `person_description` varchar(255) NOT NULL,
  `person_skin` varchar(30) NOT NULL,
  `person_reurl` varchar(255) NOT NULL,
  `person_father_id` int(11) NOT NULL,
  `person_father_name` varchar(255) NOT NULL,
  `person_object_id` int(11) NOT NULL,
  `person_object_name` varchar(255) NOT NULL,
  `person_douban_id` int(11) NOT NULL,
  `person_douban_celebrities` int(11) NOT NULL,
  `person_douban_name` varchar(255) NOT NULL,
  PRIMARY KEY (`person_id`),
  UNIQUE KEY `person_id` (`person_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `ff_player` (
  `player_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `player_name_zh` varchar(128) NOT NULL,
  `player_name_en` varchar(128) NOT NULL,
  `player_info` varchar(250) NOT NULL,
  `player_order` smallint(3) NOT NULL DEFAULT '0',
  `player_status` tinyint(1) NOT NULL DEFAULT '1',
  `player_copyright` smallint(3) NOT NULL DEFAULT '0',
  `player_jiexi` varchar(120) NOT NULL,
  PRIMARY KEY (`player_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;
INSERT INTO `ff_player` (`player_id`, `player_name_zh`, `player_name_en`, `player_info`, `player_order`, `player_status`, `player_copyright`, `player_jiexi`) VALUES
(1, 'Ckm3u8', 'ckm3u8', 'M3u8播放器', 1, 1, 0, '');

CREATE TABLE IF NOT EXISTS `ff_record` (
  `record_id` int(11) NOT NULL AUTO_INCREMENT,
  `record_uid` mediumint(8) NOT NULL DEFAULT '1',
  `record_sid` mediumint(8) NOT NULL DEFAULT '1',
  `record_did` mediumint(8) NOT NULL,
  `record_did_sid` tinyint(3) NOT NULL,
  `record_did_pid` smallint(6) NOT NULL,
  `record_type` tinyint(2) NOT NULL,
  `record_time` int(11) NOT NULL,
  PRIMARY KEY (`record_id`),
  UNIQUE KEY `record_id` (`record_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `ff_score` (
  `score_id` int(10) NOT NULL AUTO_INCREMENT,
  `score_uid` mediumint(8) NOT NULL,
  `score_sid` tinyint(3) NOT NULL,
  `score_did` mediumint(8) NOT NULL,
  `score_type` tinyint(3) NOT NULL,
  `score_ext` mediumint(8) NOT NULL,
  `score_addtime` int(11) NOT NULL,
  PRIMARY KEY (`score_id`),
  KEY `score_id` (`score_id`),
  KEY `score_uid` (`score_uid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `ff_slide` (
  `slide_id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `slide_oid` tinyint(3) NOT NULL,
  `slide_cid` tinyint(3) NOT NULL DEFAULT '1',
  `slide_name` varchar(255) NOT NULL,
  `slide_logo` varchar(255) NOT NULL,
  `slide_pic` varchar(255) NOT NULL,
  `slide_url` varchar(255) NOT NULL,
  `slide_content` varchar(255) NOT NULL,
  `slide_status` tinyint(1) NOT NULL,
  PRIMARY KEY (`slide_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `ff_special` (
  `special_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `special_cid` smallint(6) NOT NULL DEFAULT '0',
  `special_banner` varchar(150) NOT NULL,
  `special_logo` varchar(150) NOT NULL,
  `special_name` varchar(150) NOT NULL,
  `special_type` varchar(255) NOT NULL,
  `special_ename` varchar(255) DEFAULT NULL,
  `special_tag_name` varchar(255) NOT NULL,
  `special_ids_vod` varchar(255) DEFAULT NULL,
  `special_ids_news` varchar(255) DEFAULT NULL,
  `special_title` varchar(150) DEFAULT NULL,
  `special_keywords` varchar(150) NOT NULL,
  `special_description` varchar(255) NOT NULL,
  `special_color` char(8) NOT NULL,
  `special_skin` varchar(50) NOT NULL,
  `special_addtime` int(11) NOT NULL,
  `special_hits` mediumint(8) NOT NULL,
  `special_hits_day` mediumint(8) NOT NULL,
  `special_hits_week` mediumint(8) NOT NULL,
  `special_hits_month` mediumint(8) NOT NULL,
  `special_hits_lasttime` int(11) NOT NULL,
  `special_stars` tinyint(1) NOT NULL DEFAULT '1',
  `special_status` tinyint(1) NOT NULL,
  `special_content` text NOT NULL,
  `special_up` mediumint(8) NOT NULL,
  `special_down` mediumint(8) NOT NULL,
  `special_gold` decimal(3,1) NOT NULL,
  `special_golder` smallint(6) NOT NULL,
  PRIMARY KEY (`special_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `ff_tag` (
  `tag_id` mediumint(8) NOT NULL,
  `tag_cid` tinyint(2) DEFAULT '0',
  `tag_name` varchar(50) NOT NULL,
  `tag_list` varchar(32) DEFAULT 'vod_tag' COMMENT 'vod_tag|news_tag|vod_type|news_type',
  `tag_ename` varchar(255) DEFAULT NULL,
  KEY `tag_id` (`tag_id`),
  KEY `tag_cid` (`tag_cid`),
  KEY `tag_list` (`tag_list`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `ff_user` (
  `user_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `user_pid` mediumint(8) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_pwd` char(32) NOT NULL,
  `user_score` mediumint(9) NOT NULL,
  `user_status` tinyint(1) NOT NULL DEFAULT '1',
  `user_follow` mediumint(8) NOT NULL DEFAULT '0',
  `user_group` tinyint(1) NOT NULL,
  `user_logip` varchar(16) NOT NULL,
  `user_lognum` smallint(5) NOT NULL DEFAULT '1',
  `user_logtime` int(10) NOT NULL,
  `user_joinip` varchar(16) NOT NULL,
  `user_jointime` int(10) NOT NULL,
  `user_deadtime` int(10) NOT NULL,
  `user_qq` varchar(20) NOT NULL,
  `user_email` varchar(50) NOT NULL,
  `user_face` varchar(50) NOT NULL,
  `user_up` mediumint(8) NOT NULL DEFAULT '0',
  `user_down` mediumint(9) NOT NULL DEFAULT '0',
  `user_hits` mediumint(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

INSERT INTO `ff_user` (`user_id`, `user_pid`, `user_name`, `user_pwd`, `user_score`, `user_status`, `user_follow`, `user_group`, `user_logip`, `user_lognum`, `user_logtime`, `user_joinip`, `user_jointime`, `user_deadtime`, `user_qq`, `user_email`, `user_face`, `user_up`, `user_down`, `user_hits`) VALUES
(1, 0, '游客', '7fef6171469e80d32c0559f88b377245', 842, 1, 0, 0, '127.0.0.1', 1, 1502804676, '', 1970, 1503236536, '', '11010086@qq.com', '', 0, 0, 0);

CREATE TABLE IF NOT EXISTS `ff_vod` (
  `vod_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `vod_cid` smallint(6) NOT NULL,
  `vod_name` varchar(255) NOT NULL,
  `vod_ename` varchar(255) DEFAULT '',
  `vod_title` varchar(255) DEFAULT '',
  `vod_keywords` varchar(255) DEFAULT '',
  `vod_type` varchar(255) DEFAULT '',
  `vod_color` char(8) DEFAULT '',
  `vod_actor` varchar(255) DEFAULT '',
  `vod_director` varchar(255) DEFAULT '',
  `vod_content` text,
  `vod_pic` varchar(255) DEFAULT '',
  `vod_pic_bg` varchar(255) DEFAULT '',
  `vod_pic_slide` varchar(255) DEFAULT '',
  `vod_area` char(10) DEFAULT '',
  `vod_language` char(10) DEFAULT '',
  `vod_year` smallint(4) DEFAULT '0',
  `vod_continu` varchar(20) DEFAULT '0',
  `vod_total` mediumint(9) DEFAULT '0',
  `vod_isend` tinyint(1) DEFAULT '1',
  `vod_addtime` int(11) DEFAULT '0',
  `vod_filmtime` int(11) DEFAULT '0',
  `vod_hits` mediumint(8) DEFAULT '0',
  `vod_hits_day` mediumint(8) DEFAULT '0',
  `vod_hits_week` mediumint(8) DEFAULT '0',
  `vod_hits_month` mediumint(8) DEFAULT '0',
  `vod_hits_lasttime` int(11) DEFAULT '0',
  `vod_stars` tinyint(1) DEFAULT '1',
  `vod_status` tinyint(1) DEFAULT '1',
  `vod_up` mediumint(8) DEFAULT '0',
  `vod_down` mediumint(8) DEFAULT '0',
  `vod_ispay` tinyint(1) DEFAULT '0',
  `vod_price` smallint(6) DEFAULT '0',
  `vod_trysee` smallint(6) NOT NULL DEFAULT '0',
  `vod_play` varchar(255) DEFAULT '',
  `vod_server` varchar(255) DEFAULT '',
  `vod_url` longtext,
  `vod_inputer` varchar(30) DEFAULT '',
  `vod_reurl` varchar(255) DEFAULT '',
  `vod_jumpurl` varchar(150) DEFAULT '',
  `vod_letter` char(2) DEFAULT '',
  `vod_skin` varchar(30) DEFAULT '',
  `vod_gold` decimal(3,1) DEFAULT '0.0',
  `vod_golder` smallint(6) DEFAULT '0',
  `vod_length` smallint(6) DEFAULT '0',
  `vod_weekday` varchar(60) DEFAULT '',
  `vod_series` varchar(120) DEFAULT '',
  `vod_copyright` smallint(3) DEFAULT '0',
  `vod_state` varchar(30) DEFAULT '',
  `vod_version` varchar(30) DEFAULT '',
  `vod_tv` varchar(30) DEFAULT '',
  `vod_douban_id` int(11) DEFAULT '0',
  `vod_douban_score` decimal(3,1) DEFAULT '0.0',
  `vod_scenario` longtext,
  `vod_lines` text NOT NULL,
  `vod_watch` text NOT NULL,
  `vod_ending` text NOT NULL,
  `vod_writer` varchar(255) NOT NULL,
  `vod_producer` varchar(255) NOT NULL,
  `vod_camera` varchar(255) NOT NULL,
  `vod_editor` varchar(255) NOT NULL,
  `vod_music` varchar(255) NOT NULL,
  `vod_art` varchar(255) NOT NULL,
  `vod_extend` text,
  PRIMARY KEY (`vod_id`),
  KEY `vod_cid` (`vod_cid`),
  KEY `vod_up` (`vod_up`),
  KEY `vod_down` (`vod_down`),
  KEY `vod_addtime` (`vod_addtime`,`vod_cid`),
  KEY `vod_hits` (`vod_hits`,`vod_cid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;