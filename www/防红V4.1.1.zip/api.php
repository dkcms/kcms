<?php
/**
 * API接口
**/
include("includes/common.php");
$method=isset($_GET['method'])?$_GET['method']:null;
switch ($method) {
    case 'joinqun':
        $qun=isset($_GET['qun'])?$_GET['qun']:'295023774';
        $ua = strtolower($_SERVER['HTTP_USER_AGENT']);
        if(strpos($ua, 'windows') ){
            $data=get_curl('http://shang.qq.com/wpa/g_wpa_get?guin='.$qun.'&t='.time(),0,'http://qun.qq.com/join.html');
            $arr=json_decode($data,true);
            $idkey=$arr['result']['data'][0]['key'];
            header('Location:http://shang.qq.com/wpa/qunwpa?idkey='.$idkey);
        }else{
            header('Location:mqqapi://card/show_pslcard?src_type=internal&version=1&card_type=group&source=qrcode&uin='.$qun);
        }
        unset($qun,$data,$arr,$idkey);
        exit();
        break;
    case 'get.title':
        $url = (isset($_GET['url']))?$_GET['url']:$_POST['url'];
        if(!isset($url))  exit(json_encode(array('code'=>201601,'msg'=>'URL不能为空')));
        $row = $DB->get_row("select * from `uomg_report` where `url` like '%".$url."%';");
        if ($row['title']) {
            exit(json_encode(array('code'=>1,'title'=>$row['title'])));
        }
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,$url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1); // 302 redirect
        curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (compatible; Baiduspider-render/2.0; +http://www.baidu.com/search/spider.html)");
        $ret=curl_exec($ch);
        curl_close($ch);
        preg_match('/<title>(.*)<\/title>/i',$ret,$title);
        $title = str_replace(array("\r\n", "\r", "\n", ',', ' '), '', $title[1]); 
        if(!isset($title))  exit(json_encode(array('code'=>201602,'msg'=>'获取失败，请重试！')));
        
        $DB->query("update `uomg_report` SET title='".$title."' where id='".$row['id']."';");

        $result=array(
            'code'=>1,
            'title'=>$title
        );
        print_r(json_encode($result));

        unset($url,$ch,$result,$ret,$title);
        exit();
        break;
    case 'qqtalk':
        $qq = isset($_GET['qq'])?$_GET['qq']:'774740085';
        $ua = strtolower($_SERVER['HTTP_USER_AGENT']);
        if(strpos($ua, 'android') != false || strpos($ua, 'ipad') != false || strpos($ua, 'iphone') != false ){
            $url = 'mqqwpa://im/chat?chat_type=wpa&version=1&src_type=web&web_src=oicqzone.com&uin='.$qq;
            header('Location:'.$url);
        }elseif (strpos($ua, 'windows') != false) {
            header('Location:tencent://Message/?uin='.$qq);
        }else{
            header('Location:http://wpa.qq.com/msgrd?v=3&site=qq&menu=yes&uin='.$qq);
        }
        unset($_POST,$_GET,$qq,$ua);
        exit();
        break;
    case 'index_num':
        $urls=$DB->count("SELECT count(*) FROM uomg_domain WHERE 1"); //获取域名数量
        $sum=$DB->get_row("SELECT SUM(count) FROM uomg_report");//获取生成数量
        $logs = $sum['SUM(count)'];
        $json=array(
            'UrlUseNum'=>$urls,
            'ApiUseNum'=>$logs
        );
        unset($urls,$sum,$logs,$method);
        exit(json_encode($json));
        break;
    case 'tj':
        if ($_GET['uid'] == 'undefined') exit('401');
        $row = $DB->get_row("select * from `uomg_report` where uid='".$_GET['uid']."';");
        $url_arr = parse_url($row['url']);
        $domain = $url_arr['host'];
        if (!$domain) exit('401');
        if ($domain == 't.cn') exit('401');
        if ($domain == '') exit('401');
        $date = date("Y-m-d");
        $user_agent = $_SERVER['HTTP_USER_AGENT'];
        $remoteip=real_ip();
        $DB->query("insert into `uomg_log` (`domain`,`click_time`,`user_agent`,`ip_address`) values ('".$domain."','".$date."','".$user_agent."','".$remoteip."')");
        exit($date);
        unset($_GET,$url_arr,$domain,$date,$user_agent,$remoteip,$method);
        break;
    case 'background':
        $url='http://www.lofter.com/dwr/call/plaincall/ActMiscBean.getLatestIndexImages.dwr';
        $post='callCount=1&scriptSessionId=${scriptSessionId}187&c0-scriptName=ActMiscBean&c0-methodName=getLatestIndexImages&c0-id=0&c0-param0=number:100&batchId=126886&';
        $referer='http://www.lofter.com/login?urschecked=true';
        $rel= get_curl($url,$post,$referer);
        preg_match_all('/imageUrl=[\"\"](.*?)[\"\"]/i',$rel,$matches);
        $key=array_rand($matches[1],1);
        $rel=str_replace(array('http://','imgcdn.ph'), array('https://','img0.ph'), $matches[1][$key]);
        if ($rel) {
            $json = array('code' => 1,'msg' => $rel);
        }else{
            $json = array('code' => 5,'msg' => '获取失败！');
        }
        unset($url,$post,$referer,$rel,$key,$method);
        exit(json_encode($json));
        break;
    case 'append':
        if ($_POST['key'] != $conf['apikey']) exit('{"code":10008,"msg":"URL不能为空"}');
        $i=0;
        $type=addslashes($_POST['item']);
        $text=trim(strtolower($_POST['text']));
        if($text==NULL or $type==NULL){
            $json = array('{"code":5,"msg":"请确保每项都不为空！"}');
        } else {
            $val = str_replace('http://', '', $text);
            $val = str_replace('https://', '', $val);
            $val = str_replace("\n\r", '', $text);
            if ($type == 'domain') {
                $myrow=$DB->get_row("select * from `uomg_domain` where domain='$val' limit 1");
                if (!$myrow){
                    $sql = $DB->get_row("insert into `uomg_domain` (`domain`,`date`,`status`) values ('".$val."','".$date."','1')");
                    $i++;
                }
            }elseif ($type == 'u_black') {
                if (!$DB->get_row("select * from `uomg_auth` where domain='".$val."';")) {
                    $DB->query("insert into `uomg_auth` (uid,domain,ios_qq,an_qq,ios_vx,an_vx,other,add_time,end_time,status) value 
                    ('-1','".$val."','".$conf['stasis_iosqq']."','".$conf['stasis_anqq']."','".$conf['stasis_ioswx']."','".$conf['stasis_anwx']."','".$conf['stasis_other']."','".$date."',DATE_ADD('".$date."', INTERVAL '30' DAY ),2);");
                    $i++;
                }
            }elseif ($type == 'u_white') {
                if (!$DB->get_row("select * from `uomg_auth` where domain='".$val."';")) {
                    $DB->query("insert into `uomg_auth` (uid,domain,ios_qq,an_qq,ios_vx,an_vx,other,add_time,end_time,status) value 
                    ('-1','".$val."','".$conf['stasis_iosqq']."','".$conf['stasis_anqq']."','".$conf['stasis_ioswx']."','".$conf['stasis_anwx']."','".$conf['stasis_other']."','".$date."',DATE_ADD('".$date."', INTERVAL '30' DAY ),1);");
                    $i++;
                }
            }elseif ($type == 'i_black') {
                $myrow=$DB->get_row("select * from `uomg_iptable` where ip='$val' limit 1");
                if (!$myrow) {
                    $DB->query("insert into `uomg_iptable` (`ip`,`date`,`type`) values ('".$val."','".$date."','2')");
                    $i++;
                }
            }elseif ($type == 'i_white') {
                $myrow=$DB->get_row("select * from `uomg_iptable` where ip='$val' limit 1");
                if (!$myrow) {
                    $DB->query("insert into `uomg_iptable` (`ip`,`date`,`type`) values ('".$val."','".$date."','1')");
                    $i++;
                }
            }
            $json = array('code' => 1,'msg' => '成功添加'.$i.'条记录！');
        }
        unset($i,$type,$text,$_POST,$val,$myrow);
        exit(json_encode($json));
        break;
    case 'ip_update':
        if ($_POST['key'] != $conf['apikey']) exit('{"code":10008,"msg":"URL不能为空"}');
        $newip=addslashes($_POST['newip']);
        $oldip=addslashes($_POST['oldip']);
        $DB->query("update `uomg_domain` SET domain='".$newip."',date='".$date."',status=1 where domain='".$oldip."';");
        $myrow = $DB->get_row("select * from `uomg_domain` where domain='".$newip."' limit 1");
        if ($myrow) exit('{"code":1,"msg":"成功更新记录！"}');
        else exit('{"code":0,"msg":"更新记录失败！"}');
        break;
    case 'uploads':
        if (class_exists('CURLFile')) { // php 5.5
            $post['file'] = new \CURLFile(realpath($_FILES['imageData']['tmp_name']));
        } else {
            $post['file'] = '@'.realpath($_FILES['imageData']['tmp_name']);
        }
        $rel = get_curl('https://search.jd.com/image?op=upload',$post);
        preg_match('/callback(?:\(\")(.*)(?:\"\))/i',$rel,$matches);
        if (!$matches[1]) {
            $arr = array('code'=>0,'msg'=>'图片上传失败！');
        }else{
            $arr = array(
                'code'  =>  200,
                'imgurl'=>  'https://img'.rand(10,14).'.360buyimg.com/uba/'.$matches[1]
            );
        }
        exit(json_encode($arr));
        break;
    default:
        $json = array('code' => 5,'msg' => '参数错误！');
        exit(json_encode($json));
        break;
}
