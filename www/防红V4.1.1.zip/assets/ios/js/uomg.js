$(function () {
    $("#from_login").submit(function(data){
      var datas= $("#from_login").serialize();
      $.ajax({
        url:'login.php',
        data:datas,
        type:"POST",
        dataType:"json",
        success:function(msg){
          console.log(msg)
          var strJson = JSON.stringify(msg) 
          var data = $.parseJSON(strJson);
          if (data.code == 1) {
            layer.alert(data.msg, {icon: data.code});
            window.location.href='./';
          }else{
            layer.msg(data.msg);
          }

        },
        error:function(error){
          alert("服务器连接失败！！");
        }

      });
      return false;
    });
    tableCheck = {
        init:function  () {
            $(".layui-form-checkbox").click(function(event) {
                if($(this).hasClass('layui-form-checked')){
                    $(this).removeClass('layui-form-checked');
                    if($(this).hasClass('header')){
                        $(".layui-form-checkbox").removeClass('layui-form-checked');
                    }
                }else{
                    $(this).addClass('layui-form-checked');
                    if($(this).hasClass('header')){
                        $(".layui-form-checkbox").addClass('layui-form-checked');
                    }
                }
                
            });
        },
        getData:function  () {
            var obj = $('.table').find('tr > td:first-child input:checkbox');
            //var obj = $('#dataTable1').not('tr > td:first-child input:checkbox');
            var arr=[];
            obj.each(function(index, el) {
                if (this.checked) {
                    arr.push(obj.eq(index).attr('data-id'));
                }
            });
            return arr;
        },
        getHref:function  () {
            var obj = $('.table').find('tr > td:first-child input:checkbox');
            var arr=[];
            obj.each(function(index, el) {
                if (this.checked) {
                    arr.push(obj.eq(index).parents('td').next().next().find('a').attr('href'));
                }
            });
            return arr;
        }
    }
    //开启表格多选
    tableCheck.init();
})
