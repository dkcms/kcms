<?php
/*
Template Name:main.js
Description:stasis js
Version:4.0
Author:墨渊
Author Url:http://www.aeink.com
*/
$T_ver = preg_replace('/^ver=(.*)$/i','$1',$_SERVER["QUERY_STRING"]);
?>  
  var url = window.document.location.href.toString();
  url = url.replace(/=/, "");
  url = url.replace(go_format, "");
  var u = url.split("?");
  GetTj();
  if(typeof(u[1]) == "string" && navigator.language.indexOf("zh")>=0){
    Turl = longurl.replace(/http:\/\//, "");
    Turl = Turl.replace(/https:\/\//, "");
    if(navigator.userAgent.indexOf("QQ/")>0){
      ob("mttbrowser://url="+longurl);
      <?php
        $useragent = strtolower($_SERVER['HTTP_USER_AGENT']);
        if ((strpos($useragent, 'iphone')!==false || strpos($useragent, 'ipod')!==false)&& $_SERVER['HTTP_REFERER'] != false) {
          echo 'openurl("ucbrowser://"+longurl);
          openurl("baiduboxapp://browse?url="+longurl);
          openurl("qihoobrowser://browse?url="+longurl)
          openurl("dolphin://"+longurl);
          openurl("googlechrome://"+Turl);
          openurl("opera-http://"+longurl);
          openurl("quark://"+longurl);
          openurl("browser2345://"+longurl);
          openurl("taobao://"+Turl);';
        }else{
          echo '$("*").on("click",function(){
              openurl("mttbrowser://url="+longurl);
              openurl("ucweb://"+longurl);
              openurl("ttg://tburl?url="+longurl);
              openurl("qihoobrowser://browse?url="+longurl);
              openurl("googlechrome://browse?url="+Turl);
              openurl("mibrowser:"+Turl);
              openurl("taobao://"+Turl);
            });';
        }
      ?>
      function openurl(url) {var a = document.createElement('iframe');a.setAttribute('src', url);a.setAttribute('style', 'display:none');document.body.appendChild(a);}
      function ob(u){document.getElementById(rid).href= u;document.getElementById(rid).click();}
      if (t_go_url !='no') {window.location.replace(t_go_url);}
    }else if(navigator.userAgent.indexOf("MicroMessenger")>0){
      $("body").css("background-color","#f5f5f5");
      $("#Pan_QQ").css("display","none");
      $("#Pan_WX").css("display","block");
      setRootFontSize();
      if(vxurl != false) {window.location.replace(vxurl + "/jump/go?backurl=" + longurl);}
    }else{
      document.getElementById(rid).href= longurl;
      setTimeout(function(){document.getElementById(rid).click();},delay);
    }
  };
  window.onresize = function () {setRootFontSize();}
  function setRootFontSize() {$("html").css("font-size", document.body.clientWidth / 15 + "px");}
  function GetTj() {$.getJSON("api.php?method=tj&uid="+u[1],function(data){}) ;}
  var _hmt = _hmt || [];
  (function() {
    var hm = document.createElement("script");
    hm.src = "https://hm.baidu.com/hm.js?"+bdtjid;
    var s = document.getElementsByTagName("script")[0]; 
    s.parentNode.insertBefore(hm, s);
    var cnzz = document.createElement("script");
    cnzz.src = "https://s4.cnzz.com/z_stat.php?id="+cnzzid+"&web_id="+cnzzid;
    document.getElementsByTagName('body')[0].appendChild(cnzz);
  })();
  function getQueryString(name) { 
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i"); 
    var r = window.location.search.substr(1).match(reg); 
    if (r != null) return unescape(r[2]); 
    return null; 
  } 