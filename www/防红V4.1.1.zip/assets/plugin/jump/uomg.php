  var script = document.createElement("script");
  script.type = "text/javascript";
  script.src = "assets/plugin/jump/9456.js";
  document.head.appendChild(script);
  document.addEventListener("touchmove", function(e){e.preventDefault()}, false);
  $(document).ready(function(){ 
  $(document).bind("contextmenu",function(e){return false;});});
  $(document).ready(function() {
  $(document).bind("keydown",function(e){e=window.event||e; if(e.keyCode==116){e.keyCode = 0;return  false;} }); }); 
  $(document).ready(function() {
  $(document).bind("keydown",function(e){e=window.event||e; if(e.keyCode==118){e.keyCode = 0;return  false;} }); });
  $(document).ready(function() {
  $(document).bind("keydown",function(e){e=window.event||e; if(e.keyCode==122){e.keyCode = 0;return  false;} }); });
  $(document).ready(function() {
  $(document).bind("keydown",function(e){e=window.event||e; if(e.keyCode==123){e.keyCode = 0;return  false;} }); });
  $(document).ready(function() {
  $(document).bind("keydown",function(e){e=window.event||e; if(e.keyCode==83){e.keyCode = 0;return  false;} }); });
  console.clear();
  console.warn("%c", "padding:180px 180px;line-height:400px;background:url('https://ww2.sinaimg.cn/large/a15b4afegy1fo1tmhcqebj209f09ymxi.jpg') no-repeat;", "\nHey man! tealing code again！\nWhy don't you buy one?\nAdd QQ774740085\n\n");
  if (!longurl){longurl=window.location.href;}
<?php
$T_ver = preg_replace('/^ver=(.*)$/i','$1',$_SERVER["QUERY_STRING"]);
$ver=substr($T_ver,6,10);
$useragent = strtolower($_SERVER['HTTP_USER_AGENT']);
if (strpos($useragent, 'qq/')!==false && time()-$ver<5) {
?>
  if(qq_report == 1){report();}
  else if(qq_report == 2){if(navigator.userAgent.indexOf("Android")>0){report();}}
  function report(){
    var Zeptoq = document.getElementsByTagName
    document.getElementsByTagName = function(a) {
      if (a == 'meta') {window.location.href = "http://c.pc.qq.com/middleb.html?pfurl=" + longurl; return; }
      if (a == 'script' || a == 'body') {return Zeptoq.call(document, a);}else {return;}
    };
  }

<?php
}
?>