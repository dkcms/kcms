var frogMode = function() {	
	
}
